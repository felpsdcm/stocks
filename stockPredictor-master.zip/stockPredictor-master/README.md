
## Project Overview

Stock market movement prediction using LSTM Deep Neural Networks and machine learning algorithms. 
<< This predictions are not accurate and are not intended to use for personal investment decision makings. >> 

## Software and Library Requirements

This project requires the following software and libraries:

* Python 3.5
* NumPy
* pandas
* matplotlib
* scikit-learn
* iPython Notebook
* Karas
* TensorFlow
* Yahoo! Finance

